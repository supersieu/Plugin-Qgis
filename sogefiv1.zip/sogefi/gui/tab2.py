import os
from qgis.PyQt import QtWidgets, uic

from qgis.core import *
from qgis.gui import *

plugin_folder = os.path.dirname(os.path.dirname(__file__))
Tab2Widget, _ = uic.loadUiType(os.path.join(
    plugin_folder, 'ui', 'tab2.ui'))

class Tab2(QtWidgets.QWidget, Tab2Widget):

    def __init__(self, iface, parent=None):
        super(Tab2, self).__init__(parent)
        self.setupUi(self)
        self.url = [
            "https://a.monterritoire.net/mapcache/tms/1.0.0/mtosm/{z}/{x}/{-y}.jpg",
            "https://a.monterritoire.net/sans/tms/1.0.0/mtosm/{z}/{x}/{-y}.jpg",
            "https://a.monterritoire.net/gs/tms/1.0.0/mtosm/{z}/{x}/{-y}.png",
            "https://a.monterritoire.net/gs-sans/tms/1.0.0/mtosm/{z}/{x}/{-y}.png",
            "https://a.monterritoire.net/hr/tms/1.0.0/mtosm/{z}/{x}/{-y}.png",
            "https://a.monterritoire.net/contraste/tms/1.0.0/mtosm/{z}/{x}/{-y}.png",
            "https://a.monterritoire.net/greengems/tms/1.0.0/gg/{z}/{x}/{-y}.jpg",
            "https://a.monterritoire.net/greengemsrecycled/tms/1.0.0/ggr/{z}/{x}/{-y}.jpg"
        ]
        self.radioButton1.toggled.connect(
            lambda checked: self.ajouterRaster(checked, self.url[0]))
        self.radioButton2.toggled.connect(
            lambda checked: self.ajouterRaster(checked, self.url[1]))
        self.radioButton3.toggled.connect(
            lambda checked: self.ajouterRaster(checked, self.url[2]))
        self.radioButton4.toggled.connect(
            lambda checked: self.ajouterRaster(checked, self.url[3]))
        self.radioButton5.toggled.connect(
            lambda checked: self.ajouterRaster(checked, self.url[4]))
        self.radioButton6.toggled.connect(
            lambda checked: self.ajouterRaster(checked, self.url[5]))
        self.radioButton7.toggled.connect(
            lambda checked: self.ajouterRaster(checked, self.url[6]))
        self.radioButton8.toggled.connect(
            lambda checked: self.ajouterRaster(checked, self.url[7]))

    def ajouterRaster(self, checked, url):
        if checked:
            listLayer = QgsProject.instance().mapLayersByName("Fond plan sogefi")
            layer = None
            if len(listLayer) > 0:
                layer = listLayer[0]

            if layer:
                url = "type=xyz&url=" + url
                name = layer.name()
                provider = layer.providerType()
                op = layer.dataProvider().ProviderOptions()
                layer.setDataSource(url, name, provider, op)
                layer.reload()
            else:
                url = "type=xyz&url=" + url
                rlayer = QgsRasterLayer(url, "Fond plan sogefi", 'wms')
                if rlayer.isValid():
                    QgsProject.instance().addMapLayer(rlayer)
