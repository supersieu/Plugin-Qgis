import os
import json
import re
from shapely.geometry import shape

from qgis.PyQt import QtWidgets, uic
from qgis.PyQt.QtCore import Qt, pyqtSignal, QUrl, QByteArray, QVariant
from qgis.PyQt.QtGui import QColor
from qgis.PyQt.QtNetwork import QNetworkAccessManager, QNetworkRequest, QNetworkReply

from qgis.core import *
from qgis.gui import *

from sogefi.gui.drawTools import DrawRect, DrawLine, DrawCircle, DrawPolygon
from sogefi.gui.utils import CheckBox

plugin_folder = os.path.dirname(os.path.dirname(__file__))
StackCogWidget, _ = uic.loadUiType(os.path.join(
    plugin_folder, 'ui', 'apiStackCog.ui'))

class StackCog(QtWidgets.QWidget, StackCogWidget):

    start = pyqtSignal()
    done = pyqtSignal()

    def __init__(self, iface, featureTab, data, parent=None):
        super(StackCog, self).__init__(parent)
        self.setupUi(self)
        self.iface = iface
        self.data = data
        self.radioButton1.setAutoExclusive(False)
        self.radioButton1.setChecked(False)
        self.radioButton1.setAutoExclusive(True)
        self.radioButton2.setAutoExclusive(False)
        self.radioButton2.setChecked(False)
        self.radioButton2.setAutoExclusive(True)
        self.groupBox.hide()
        self.groupBox1.hide()
        self.groupBox2.hide()
        self.checkBoxAll.hide()
        self.tableWidget.hide()
        self.radioButton1.toggled.connect(self.option1)
        self.radioButton2.toggled.connect(self.option2)
        self.comboBox.clear()
        self.comboBox.addItem("", "none")
        self.comboBox.addItem("Régions", "regions")
        self.comboBox.addItem("Départements", "departements")
        self.comboBox.addItem("EPCIs", "epcis")
        self.comboBox.addItem("Communes", "communes")
        self.comboBox.view().setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.comboBox.setStyleSheet("combobox-popup: 0;")
        self.checkBoxAll.stateChanged.connect(self.checkAll)

        self.featureTab = featureTab
        self.fetcherTab = []
        self.idTab = []
        self.tool = None
        self.canvas = iface.mapCanvas()
        self.drawLineBtn.clicked.connect(self.drawLine)
        self.drawRecBtn.clicked.connect(self.drawRec)
        self.drawCirBtn.clicked.connect(self.drawCercle)
        self.drawPolyBtn.clicked.connect(self.drawPolygon)
        self.currentMapTool = QgsMapToolPan(self.canvas)
        self.toolName = None
        self.geometry = []
        self.figure = None
        self.layerName = ''
        self.activeTab = {}

        # Cog
        self.regionsCogEntite = {}
        self.departementsCogEntite = {}
        self.epcisCogEntite = {}
        self.communesCogEntite = {}
        self.regionsCogGeo = {}
        self.departementsCogGeo = {}
        self.epcisCogGeo = {}
        self.communesCogGeo = {}

    def option1(self, checked):
        if checked:
            self.checkBoxAll.setCheckState(Qt.Unchecked)
            self.groupBox.show()
            self.groupBox1.hide()
            self.groupBox2.show()
            self.checkBoxAll.show()
            self.tableWidget.show()
            try:
                self.comboBox.disconnect()
            except TypeError:
                pass
            self.comboBox.currentIndexChanged.connect(self.populateTableEntite)
            self.comboBox.setCurrentIndex(0)
        else:
            self.groupBox.hide()
            self.groupBox1.hide()
            self.groupBox2.hide()
            self.checkBoxAll.hide()
            self.tableWidget.hide()

    def option2(self, checked):
        if checked:
            self.checkBoxAll.setCheckState(Qt.Unchecked)
            self.groupBox.show()
            self.groupBox1.show()
            self.groupBox2.show()
            self.checkBoxAll.show()
            self.tableWidget.show()
            try:
                self.comboBox.disconnect()
            except TypeError:
                pass
            self.comboBox.currentIndexChanged.connect(self.populateTableGeo)
            self.comboBox.setCurrentIndex(0)
        else:
            self.groupBox.hide()
            self.groupBox1.hide()
            self.groupBox2.hide()
            self.checkBoxAll.hide()
            self.tableWidget.hide()

    def reset(self):
        self.radioButton1.setAutoExclusive(False)
        self.radioButton1.setChecked(False)
        self.radioButton1.setAutoExclusive(True)
        self.radioButton2.setAutoExclusive(False)
        self.radioButton2.setChecked(False)
        self.radioButton2.setAutoExclusive(True)
        self.comboBox.setCurrentIndex(0)

        self.layerName = ''
        self.fetcherTab.clear()
        self.idTab.clear()
        self.geometry.clear()
        self.activeTab.clear()
        self.tool = None
        self.toolName = None
        self.figure = None
        self.currentMapTool = QgsMapToolPan(self.canvas)
        self.iface.mapCanvas().setMapTool(self.currentMapTool)
        self.label_2.setText('')
        self.label_3.setText('')
        self.checkBoxAll.setCheckState(Qt.Unchecked)
        self.tableWidget.clear()
        self.tableWidget.setRowCount(0)
        self.tableWidget.setColumnCount(0)
        header = self.tableWidget.horizontalHeader()
        header.hide()

        # Cog
        self.regionsCogEntite.clear()
        self.departementsCogEntite.clear()
        self.epcisCogEntite.clear()
        self.communesCogEntite.clear()
        self.regionsCogGeo.clear()
        self.departementsCogGeo.clear()
        self.epcisCogGeo.clear()
        self.communesCogGeo.clear()

    def drawLine(self):
        if isinstance(self.tool, DrawLine):
            self.iface.mapCanvas().setMapTool(self.tool)
            if self.figure is not None:
                self.tool.rb.setToGeometry(self.figure, None)
        else:
            if self.tool:
                self.tool.reset()
            self.tool = DrawLine(self.iface)
            self.iface.mapCanvas().setMapTool(self.tool)
            self.tool.selectionDone.connect(self.drawEnd)
            self.toolName = "Lin"

    def drawRec(self):
        if isinstance(self.tool, DrawRect):
            self.iface.mapCanvas().setMapTool(self.tool)
            if self.figure is not None:
                self.tool.rb.setToGeometry(self.figure, None)
        else:
            if self.tool:
                self.tool.reset()
            self.tool = DrawRect(self.iface)
            self.iface.mapCanvas().setMapTool(self.tool)
            self.tool.selectionDone.connect(self.drawEnd)
            self.toolName = "Rec"

    def drawCercle(self):
        if isinstance(self.tool, DrawCircle):
            self.iface.mapCanvas().setMapTool(self.tool)
            if self.figure is not None:
                self.tool.rb.setToGeometry(self.figure, None)
        else:
            if self.tool:
                self.tool.reset()
            self.tool = DrawCircle(self.iface, 40)
            self.iface.mapCanvas().setMapTool(self.tool)
            self.tool.selectionDone.connect(self.drawEnd)
            self.toolName = "Cer"

    def drawPolygon(self):
        if isinstance(self.tool, DrawPolygon):
            self.iface.mapCanvas().setMapTool(self.tool)
            if self.figure is not None:
                self.tool.rb.setToGeometry(self.figure, None)
        else:
            if self.tool:
                self.tool.reset()
            self.tool = DrawPolygon(self.iface)
            self.iface.mapCanvas().setMapTool(self.tool)
            self.tool.selectionDone.connect(self.drawEnd)
            self.toolName = "Pol"

    def drawEnd(self):
        self.geometry.clear()
        rb = self.tool.rb
        g = rb.asGeometry()
        self.figure = g
        for feature in self.featureTab:
            geominter = feature.geometry().intersection(g)
            if not geominter.isEmpty():
                self.geometry.append(geominter)
        self.checkBoxAll.setCheckState(Qt.Unchecked)
        self.regionsCogGeo.clear()
        self.departementsCogGeo.clear()
        self.epcisCogGeo.clear()
        self.communesCogGeo.clear()
        self.populateTableGeo()

    def populateTableEntite(self):
        self.label_2.setText('')
        self.label_3.setText('')
        self.checkBoxAll.setCheckState(Qt.Unchecked)
        self.activeTab = {}
        self.layerName = f'Contours des {self.comboBox.currentData()}'
        self.fetcherTab.clear()
        self.idTab.clear()
        self.tableWidget.clear()
        self.tableWidget.setRowCount(0)
        self.tableWidget.setColumnCount(0)
        header = self.tableWidget.horizontalHeader()
        header.hide()
        endpoint = self.comboBox.currentData()
        if endpoint != 'none':
            self.radioButton1.setEnabled(False)
            self.radioButton2.setEnabled(False)
            self.groupBox2.setEnabled(False)
            self.checkBoxAll.setEnabled(False)
            self.start.emit()
            QtWidgets.QApplication.processEvents()

            url = self.data['cog']['endpoint'][endpoint]['byId']['intersects']
            startReq = True
            tab = {}
            if endpoint == 'regions':
                tab = self.regionsCogEntite
                if len(self.regionsCogEntite) > 0:
                    startReq = False
            elif endpoint == 'departements':
                tab = self.departementsCogEntite
                if len(self.departementsCogEntite) > 0:
                    startReq = False
            elif endpoint == 'epcis':
                tab = self.epcisCogEntite
                if len(self.epcisCogEntite) > 0:
                    startReq = False
            elif endpoint == 'communes':
                tab = self.communesCogEntite
                if len(self.communesCogEntite) > 0:
                    startReq = False
            self.activeTab = tab
            if startReq:
                for feature in self.featureTab:
                    body = json.dumps(
                        {"geojson": json.loads(feature.geometry().asJson())})
                    data = QByteArray()
                    data.append(body)
                    manager = QNetworkAccessManager(self)
                    manager.finished[QNetworkReply].connect(
                        lambda reply, tab=tab, endpoint=endpoint: self.populateTableHandler(reply, tab, endpoint))
                    req = QNetworkRequest(QUrl(url))
                    req.setHeader(
                        QNetworkRequest.ContentTypeHeader, "application/json")
                    manager.post(req, data)
            self.miseAJourInfo(tab, endpoint)
            fini = True
            for i in self.fetcherTab:
                if (i.reply() is None) or (not i.reply().isFinished()):
                    fini = False
            if fini and not startReq:
                self.miseAJourInfo(tab, endpoint, True)
                self.radioButton1.setEnabled(True)
                self.radioButton2.setEnabled(True)
                self.groupBox2.setEnabled(True)
                self.checkBoxAll.setEnabled(True)
                self.done.emit()
                QtWidgets.QApplication.processEvents()

    def populateTableGeo(self):
        self.label_2.setText('')
        self.label_3.setText('')
        self.checkBoxAll.setCheckState(Qt.Unchecked)
        self.activeTab = {}
        self.layerName = f'Contours des {self.comboBox.currentData()}'
        self.fetcherTab.clear()
        self.idTab.clear()
        self.tableWidget.clear()
        self.tableWidget.setRowCount(0)
        self.tableWidget.setColumnCount(0)
        header = self.tableWidget.horizontalHeader()
        header.hide()
        endpoint = self.comboBox.currentData()
        if len(self.geometry) > 0:
            if endpoint != 'none':
                self.radioButton1.setEnabled(False)
                self.radioButton2.setEnabled(False)
                self.groupBox1.setEnabled(False)
                self.groupBox2.setEnabled(False)
                self.checkBoxAll.setEnabled(False)
                self.start.emit()
                QtWidgets.QApplication.processEvents()

                url = self.data['cog']['endpoint'][endpoint]['byId']['intersects']
                startReq = True
                tab = {}
                if endpoint == 'regions':
                    tab = self.regionsCogGeo
                    if len(self.regionsCogGeo) > 0:
                        startReq = False
                elif endpoint == 'departements':
                    tab = self.departementsCogGeo
                    if len(self.departementsCogGeo) > 0:
                        startReq = False
                elif endpoint == 'epcis':
                    tab = self.epcisCogGeo
                    if len(self.epcisCogGeo) > 0:
                        startReq = False
                elif endpoint == 'communes':
                    tab = self.communesCogGeo
                    if len(self.communesCogGeo) > 0:
                        startReq = False
                self.activeTab = tab
                if startReq:
                    for geominter in self.geometry:
                        g = {"geojson": json.loads(geominter.asJson())}
                        body = json.dumps(g)
                        data = QByteArray()
                        data.append(body)
                        manager = QNetworkAccessManager(self)
                        manager.finished[QNetworkReply].connect(
                            lambda reply, tab=tab, endpoint=endpoint: self.populateTableHandler(reply, tab, endpoint))
                        req = QNetworkRequest(QUrl(url))
                        req.setHeader(
                            QNetworkRequest.ContentTypeHeader, "application/json")
                        manager.post(req, data)
                self.miseAJourInfo(tab, endpoint)
                fini = True
                for i in self.fetcherTab:
                    if (i.reply() is None) or (not i.reply().isFinished()):
                        fini = False
                if fini and not startReq:
                    self.miseAJourInfo(tab, endpoint, True)
                    self.radioButton1.setEnabled(True)
                    self.radioButton2.setEnabled(True)
                    self.groupBox1.setEnabled(True)
                    self.groupBox2.setEnabled(True)
                    self.checkBoxAll.setEnabled(True)
                    self.done.emit()
                    QtWidgets.QApplication.processEvents()

    def populateTableHandler(self, reply, tab, endpoint):
        res = str(reply.readAll(), 'utf-8')
        if (reply is not None) and reply.error() == QNetworkReply.NoError:
            resJson = json.loads(res)
            url_base = self.data['cog']['endpoint'][endpoint]['byId']['url']
            id = ''
            listLayer = QgsProject.instance().mapLayersByName(self.layerName)
            layer = None
            if len(listLayer) > 0:
                layer = listLayer[0]
            for myDict in resJson['records']:
                if 'insee' in myDict.keys():
                    id = myDict['insee']
                elif 'code_epci' in myDict.keys():
                    id = myDict['code_epci']
                if id not in self.idTab:
                    self.idTab.append(id)
                    existe = False
                    if layer:
                        for feature in layer.getFeatures():
                            if feature.fieldNameIndex('insee') != -1:
                                if feature['insee'] == id:
                                    existe = True
                                    break
                            elif feature.fieldNameIndex('code_epci') != -1:
                                if feature['code_epci'] == id:
                                    existe = True
                                    break
                    if not existe:
                        url = re.sub('\{.*\}', id, url_base)
                        fetcher = QgsNetworkContentFetcher()
                        fetcher.fetchContent(QUrl(url))
                        fetcher.finished.connect(
                            lambda fetcher=fetcher, tab=tab, endpoint=endpoint: self.ajouterTableWidget(fetcher, tab, endpoint))
                        self.fetcherTab.append(fetcher)
        self.miseAJourInfo(tab, endpoint)
        fini = True
        for i in self.fetcherTab:
            if (i.reply() is None) or (not i.reply().isFinished()):
                fini = False
        if fini:
            self.miseAJourInfo(tab, endpoint, True)
            self.radioButton1.setEnabled(True)
            self.radioButton2.setEnabled(True)
            self.groupBox1.setEnabled(True)
            self.groupBox2.setEnabled(True)
            self.checkBoxAll.setEnabled(True)
            self.done.emit()
            QtWidgets.QApplication.processEvents()
        reply.deleteLater()

    def ajouterTableWidget(self, fetcher, tab, endpoint):
        reply = fetcher.reply()
        if (reply is not None) and reply.error() == QNetworkReply.NoError:
            resJson = json.loads(fetcher.contentAsString())
            pWidget = CheckBox()
            tab[f'{id(pWidget)}'] = {
                'checkbox': pWidget,
                'checked': False,
                'rubber': None,
                'data': resJson
            }
            self.miseAJourInfo(tab, endpoint)
        fini = True
        for i in self.fetcherTab:
            if (i.reply() is None) or (not i.reply().isFinished()):
                fini = False
        if fini:
            self.miseAJourInfo(tab, endpoint, True)
            self.radioButton1.setEnabled(True)
            self.radioButton2.setEnabled(True)
            self.groupBox1.setEnabled(True)
            self.groupBox2.setEnabled(True)
            self.checkBoxAll.setEnabled(True)
            self.done.emit()
            QtWidgets.QApplication.processEvents()

    def miseAJourInfo(self, tab, endpoint, fini=False):
        self.label_2.setText(f'{len(tab)} {endpoint} trouvé !')
        self.label_3.setText(f'0/{len(tab)}')
        if fini and len(tab) > 0:
            self.tableWidget.hide()
            firstKey = list(tab.keys())[0]
            firstData = tab[firstKey]['data']
            labels = [key for key, value in firstData.items() if not(isinstance(
                value, dict) or isinstance(value, list) or value is None)]
            labels.insert(0, '')
            self.tableWidget.setColumnCount(len(labels))
            self.tableWidget.setHorizontalHeaderLabels(labels)
            header = self.tableWidget.horizontalHeader()
            for i in range(len(labels)):
                header.setSectionResizeMode(
                    i, QtWidgets.QHeaderView.ResizeToContents)
            rowPosition = self.tableWidget.rowCount()
            for itemKey in tab.keys():
                self.tableWidget.insertRow(rowPosition)
                item = tab[itemKey]
                for idx, label in enumerate(labels):
                    if label == '':
                        pWidget = CheckBox()
                        rb = QgsRubberBand(
                            self.canvas, QgsWkbTypes.PolygonGeometry)
                        rb.setColor(QColor(0, 0, 255, 50))
                        rb.setStrokeColor(QColor(0, 0, 255, 155))
                        geom = shape(item['data']['geojson'])
                        rb.setToGeometry(QgsGeometry.fromWkt(geom.wkt), None)
                        rb.hide()
                        item['checkbox'] = pWidget
                        item['rubber'] = rb
                        self.tableWidget.setItem(
                            rowPosition, idx, item['checkbox'].cell)
                        self.tableWidget.setCellWidget(
                            rowPosition, idx, item['checkbox'])
                        item['checkbox'].checkbox.clicked.connect(
                            lambda state, itemKey=itemKey, tab=tab: self.slotSelect(itemKey, tab))
                    else:
                        cell = QtWidgets.QTableWidgetItem()
                        cell.setData(Qt.DisplayRole, item['data'][label])
                        cell.setFlags(Qt.ItemIsEnabled)
                        self.tableWidget.setItem(rowPosition, idx, cell)
                rowPosition += 1
            header.show()
            self.tableWidget.show()

    def slotSelect(self, itemKey, tab):
        text = self.label_3.text().split("/")
        data = tab[str(itemKey)]
        if data['checked']:
            data['checked'] = False
            data['checkbox'].cell.updateValue(Qt.Unchecked)
            data['rubber'].hide()
            self.label_3.setText(f'{int(text[0])-1}/{text[1]}')
        else:
            data['checked'] = True
            data['checkbox'].cell.updateValue(Qt.Checked)
            data['rubber'].show()
            self.label_3.setText(f'{int(text[0])+1}/{text[1]}')

    def checkAll(self, state):
        self.tableWidget.hide()
        text = self.label_3.text().split("/")
        for key, data in self.activeTab.items():
            data['checked'] = state == Qt.Checked
            data['checkbox'].checkbox.setChecked(state == Qt.Checked)
            data['checkbox'].cell.updateValue(state)
            if state == Qt.Checked:
                data['rubber'].show()
            else:
                data['rubber'].hide()
        if state == Qt.Checked:
            if len(text) > 1:
                self.label_3.setText(f'{text[1]}/{text[1]}')
        else:
            if len(text) > 1:
                self.label_3.setText(f'0/{text[1]}')
        self.tableWidget.show()

    def importer(self):
        tab = {}
        if self.layerName == 'Contours des regions':
            if self.radioButton1.isChecked():
                tab = self.regionsCogEntite
            elif self.radioButton2.isChecked():
                tab = self.regionsCogGeo
        elif self.layerName == 'Contours des departements':
            if self.radioButton1.isChecked():
                tab = self.departementsCogEntite
            elif self.radioButton2.isChecked():
                tab = self.departementsCogGeo
        elif self.layerName == 'Contours des epcis':
            if self.radioButton1.isChecked():
                tab = self.epcisCogEntite
            elif self.radioButton2.isChecked():
                tab = self.epcisCogGeo
        elif self.layerName == 'Contours des communes':
            if self.radioButton1.isChecked():
                tab = self.communesCogEntite
            elif self.radioButton2.isChecked():
                tab = self.communesCogGeo

        keysTab = []
        if len(tab) > 0:
            self.start.emit()
            firstKey = list(tab.keys())[0]
            firstData = tab[firstKey]['data']
            listFields = []
            for key, value in firstData.items():
                if not(isinstance(value, dict) or isinstance(value, list)):
                    typeField, typeName = self.getType(value)
                    listFields.append(QgsField(key, typeField, typeName))
                elif key == 'geojson':
                    type = value['type']

            listLayer = QgsProject.instance().mapLayersByName(self.layerName)
            layer = None
            if len(listLayer) > 0:
                layer = listLayer[0]
            if layer is None:
                layer = QgsVectorLayer(type, self.layerName, "memory")
                QgsProject.instance().addMapLayer(layer)
                pr = layer.dataProvider()
                layer.startEditing()
                pr.addAttributes(listFields)
                layer.updateFields()
                layer.commitChanges()
            layer.startEditing()
            self.tableWidget.hide()
            QtWidgets.QApplication.processEvents()

            for key, data in tab.items():
                if data['checked']:
                    keysTab.append(key)
                    self.ajoutGeoJson(layer, listFields, data['data'])

            self.deleteDup(layer)
            layer.commitChanges()
            for key in keysTab:
                self.tableWidget.removeRow(tab[key]['checkbox'].cell.row())
                self.canvas.scene().removeItem(tab[key]['rubber'])
                del tab[key]

            self.tableWidget.show()
            self.miseAJourInfo(tab, self.layerName.split(' ')[-1])
            QtWidgets.QApplication.processEvents()
            self.done.emit()
            return True
        return False

    def ajoutGeoJson(self, layer, listFields, resJson):
        geom = shape(resJson['geojson'])
        if layer:
            pr = layer.dataProvider()
            fet = QgsFeature()
            fet.setGeometry(QgsGeometry.fromWkt(geom.wkt))
            fet.setFields(layer.fields())
            for field in listFields:
                fet[field.name()] = resJson[field.name()]
            pr.addFeatures([fet])
        return True

    def getType(self, object):
        if isinstance(object, str):
            return (QVariant.String, "string")
        if isinstance(object, bool):
            return (QVariant.Bool, "boolean")
        if isinstance(object, int):
            return (QVariant.Int, "integer")
        if isinstance(object, float):
            return (QVariant.Double, "double")
        return (QVariant.String, "string")

    def deleteDup(self, layer):

        duplicate_id = []
        if layer.name() == "Contours des epcis":
            name = 'code_epci'
        else:
            name = 'insee'
        for i in layer.getFeatures():
            id = f'{i[name]}'
            if (id not in duplicate_id):
                duplicate_id.append(id)
            else:
                layer.deleteFeature(i.id())
