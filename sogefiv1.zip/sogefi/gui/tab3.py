import os
from pathlib import Path
from qgis.PyQt import QtWidgets, uic

from qgis.core import *
from qgis.gui import *


plugin_folder = os.path.dirname(os.path.dirname(__file__))
Tab3Widget, _ = uic.loadUiType(os.path.join(
    plugin_folder, 'ui', 'tab3.ui'))

class Tab3(QtWidgets.QWidget, Tab3Widget):

    def __init__(self, iface, parent=None):
        super(Tab3, self).__init__(parent)
        self.setupUi(self)
        self.iface = iface
        self.btn.clicked.connect(self.parcourir)

    def parcourir(self):
        dialog = QtWidgets.QFileDialog()
        dialog.setDefaultSuffix('gpkg')
        dialog.setAcceptMode(QtWidgets.QFileDialog.AcceptSave)
        dialog.setNameFilters(['GéoPackage (*.gpkg)'])
        if dialog.exec_() == QtWidgets.QDialog.Accepted:
            self.path.setText(dialog.selectedFiles()[0])
            QtWidgets.QApplication.processEvents()
            res = self.saveGeoPackage()
            if res:
                self.iface.messageBar().pushMessage("Success",
                                                    f'Sauvegarde {self.path.text()} avec succès.', level=Qgis.Success, duration=3)
            else:
                self.iface.messageBar().pushMessage(
                    "Critical", f'Une erreur s\'est produite.', level=Qgis.Critical, duration=3)
        else:
            self.path.setText('')

    def saveGeoPackage(self):
        lyrs = self.iface.mapCanvas().layers()
        gpkgPath = self.path.text()
        if gpkgPath != '':
            for lyr in filter(lambda l: l.type() == QgsMapLayer.VectorLayer, lyrs):
                options = QgsVectorFileWriter.SaveVectorOptions()
                if not Path(gpkgPath).exists():
                    options.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteFile
                else:
                    options.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteLayer
                options.EditionCapability = QgsVectorFileWriter.CanAddNewLayer
                options.layerName = "_".join(lyr.id().split(' '))
                name = lyr.name()
                op = lyr.dataProvider().ProviderOptions()
                _writer = QgsVectorFileWriter.writeAsVectorFormat(
                    lyr, gpkgPath, options)
                if _writer[0] != QgsVectorFileWriter.NoError:
                    return False

                lyr.setDataSource(
                    gpkgPath + f'|layername={options.layerName}', name, 'ogr', op)
                lyr.reload()
            return True
        return False
