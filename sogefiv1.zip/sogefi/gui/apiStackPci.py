import os
import json
from shapely.geometry import shape

from qgis.PyQt import QtWidgets, uic
from qgis.PyQt.QtGui import QColor
from qgis.PyQt.QtCore import Qt, pyqtSignal, QUrl, QByteArray, QVariant
from qgis.PyQt.QtNetwork import QNetworkAccessManager, QNetworkRequest, QNetworkReply

from qgis.core import *
from qgis.gui import *

from sogefi.gui.drawTools import DrawRect, DrawLine, DrawCircle, DrawPolygon
from sogefi.gui.utils import CheckBox

plugin_folder = os.path.dirname(os.path.dirname(__file__))
StackPciWidget, _ = uic.loadUiType(os.path.join(
    plugin_folder, 'ui', 'apiStackPci.ui'))

class StackPci(QtWidgets.QWidget, StackPciWidget):

    start = pyqtSignal()
    done = pyqtSignal()

    def __init__(self, iface, featureTab, data, parent=None):
        super(StackPci, self).__init__(parent)
        self.setupUi(self)
        self.iface = iface
        self.data = data
        self.featureTab = featureTab
        self.tool = None
        self.canvas = iface.mapCanvas()
        self.drawLineBtn.clicked.connect(self.drawLine)
        self.drawRecBtn.clicked.connect(self.drawRec)
        self.drawCirBtn.clicked.connect(self.drawCercle)
        self.drawPolyBtn.clicked.connect(self.drawPolygon)
        self.currentMapTool = QgsMapToolPan(self.canvas)
        self.checkBoxAll.stateChanged.connect(self.checkAll)
        self.toolName = None
        self.geometry = []
        self.figure = None
        self.pciGeo = {}
        self.idTab = []
        self.labels = []
        self.listFields = []
        self.type = None

    def reset(self):
        self.label_2.setText('')
        self.label_3.setText('')
        self.tableWidget.clear()
        self.tableWidget.setRowCount(0)
        self.tableWidget.setColumnCount(0)
        self.checkBoxAll.setCheckState(Qt.Unchecked)
        self.pciGeo.clear()
        self.labels.clear()
        self.listFields.clear()
        header = self.tableWidget.horizontalHeader()
        header.hide()

    def drawLine(self):
        if isinstance(self.tool, DrawLine):
            self.iface.mapCanvas().setMapTool(self.tool)
            if self.figure is not None:
                self.tool.rb.setToGeometry(self.figure, None)
        else:
            if self.tool:
                self.tool.reset()
            self.tool = DrawLine(self.iface)
            self.iface.mapCanvas().setMapTool(self.tool)
            self.tool.selectionDone.connect(self.drawEnd)
            self.toolName = "Lin"

    def drawRec(self):
        if isinstance(self.tool, DrawRect):
            self.iface.mapCanvas().setMapTool(self.tool)
            if self.figure is not None:
                self.tool.rb.setToGeometry(self.figure, None)
        else:
            if self.tool:
                self.tool.reset()
            self.tool = DrawRect(self.iface)
            self.iface.mapCanvas().setMapTool(self.tool)
            self.tool.selectionDone.connect(self.drawEnd)
            self.toolName = "Rec"

    def drawCercle(self):
        if isinstance(self.tool, DrawCircle):
            self.iface.mapCanvas().setMapTool(self.tool)
            if self.figure is not None:
                self.tool.rb.setToGeometry(self.figure, None)
        else:
            if self.tool:
                self.tool.reset()
            self.tool = DrawCircle(self.iface, 40)
            self.iface.mapCanvas().setMapTool(self.tool)
            self.tool.selectionDone.connect(self.drawEnd)
            self.toolName = "Cer"

    def drawPolygon(self):
        if isinstance(self.tool, DrawPolygon):
            self.iface.mapCanvas().setMapTool(self.tool)
            if self.figure is not None:
                self.tool.rb.setToGeometry(self.figure, None)
        else:
            if self.tool:
                self.tool.reset()
            self.tool = DrawPolygon(self.iface)
            self.iface.mapCanvas().setMapTool(self.tool)
            self.tool.selectionDone.connect(self.drawEnd)
            self.toolName = "Pol"

    def drawEnd(self):
        self.geometry.clear()
        rb = self.tool.rb
        g = rb.asGeometry()
        self.figure = g
        for feature in self.featureTab:
            geominter = feature.geometry().intersection(g)
            if not geominter.isEmpty():
                self.geometry.append(geominter)
        self.checkBoxAll.setCheckState(Qt.Unchecked)
        self.pciGeo.clear()
        self.labels.clear()
        self.populatePciTable()

    def populatePciTable(self):
        self.label_2.setText('')
        self.label_3.setText('')
        self.idTab.clear()
        self.tableWidget.clear()
        self.tableWidget.setRowCount(0)
        self.tableWidget.setColumnCount(0)
        header = self.tableWidget.horizontalHeader()
        header.hide()
        if len(self.geometry) > 0:
            self.groupBox.setEnabled(False)
            self.checkBoxAll.setEnabled(False)
            self.start.emit()
            QtWidgets.QApplication.processEvents()

            url = self.data['pci']['endpoint']['parcelles']['byId']['intersects']
            startReq = True
            tab = self.pciGeo
            if len(self.pciGeo) > 0:
                startReq = False
            if startReq:
                for geominter in self.geometry:
                    g = {"geojson": json.loads(geominter.asJson())}
                    body = json.dumps(g)
                    data = QByteArray()
                    data.append(body)
                    manager = QNetworkAccessManager(self)
                    manager.finished[QNetworkReply].connect(
                        lambda reply, tab=tab: self.populateTablePciHandler(reply, tab))
                    req = QNetworkRequest(QUrl(url))
                    req.setHeader(
                        QNetworkRequest.ContentTypeHeader, "application/json")
                    manager.post(req, data)
            self.miseAJourInfo(tab, 'parcelles')
            if not startReq:
                self.miseAJourInfo(tab, 'parcelles', True)
                self.groupBox.setEnabled(True)
                self.checkBoxAll.setEnabled(True)
                self.done.emit()
                QtWidgets.QApplication.processEvents()

    def populateTablePciHandler(self, reply, tab):
        res = str(reply.readAll(), 'utf-8')
        if (reply is not None) and reply.error() == QNetworkReply.NoError:
            resJson = json.loads(res)
            insee = ''
            prefixe = ''
            section = ''
            numero = None
            if resJson['total'] > 0:
                self.labels = [key for key, value in resJson['records'][0].items() if not(
                    isinstance(value, dict) or isinstance(value, list) or value is None)]
                self.labels.insert(0, '')

                self.listFields = []
                for key, value in resJson['records'][0].items():
                    if not(isinstance(value, dict) or isinstance(value, list)):
                        typeField, typeName = self.getType(value)
                        self.listFields.append(
                            QgsField(key, typeField, typeName))
                    elif key == 'geojson':
                        self.type = value['type']

            for myDict in resJson['records']:
                if 'insee' in myDict.keys():
                    insee = myDict['insee']
                if 'prefixe' in myDict.keys():
                    prefixe = myDict['prefixe']
                if 'section' in myDict.keys():
                    section = myDict['section']
                if 'numero' in myDict.keys():
                    numero = myDict['numero']
                idP = f'{insee}{prefixe}{section}{numero}'

                if idP not in self.idTab:
                    self.idTab.append(idP)
                    pWidget = CheckBox()
                    rb = QgsRubberBand(
                        self.canvas, QgsWkbTypes.PolygonGeometry)
                    rb.setColor(QColor(0, 0, 255, 50))
                    rb.setStrokeColor(QColor(0, 0, 255, 155))
                    geom = shape(myDict['geojson'])
                    rb.setToGeometry(QgsGeometry.fromWkt(geom.wkt), None)
                    rb.hide()
                    tab[f'{id(pWidget)}'] = {
                        'checkbox': pWidget,
                        'checked': False,
                        'rubber': rb,
                        'data': myDict
                    }
        self.miseAJourInfo(tab, 'parcelles', True)
        self.groupBox.setEnabled(True)
        self.checkBoxAll.setEnabled(True)
        self.done.emit()
        QtWidgets.QApplication.processEvents()
        reply.deleteLater()

    def miseAJourInfo(self, tab, endpoint, fini=False):
        self.label_2.setText(f'{len(tab)} {endpoint} trouvé !')
        self.label_3.setText(f'0/{len(tab)}')
        if fini and len(tab) > 0:
            self.tableWidget.hide()
            self.tableWidget.setColumnCount(len(self.labels))
            self.tableWidget.setHorizontalHeaderLabels(self.labels)
            header = self.tableWidget.horizontalHeader()
            for i in range(len(self.labels)):
                header.setSectionResizeMode(
                    i, QtWidgets.QHeaderView.ResizeToContents)
            rowPosition = self.tableWidget.rowCount()
            for itemKey, item in tab.items():
                self.tableWidget.insertRow(rowPosition)
                for idx, label in enumerate(self.labels):
                    if label == '':
                        self.tableWidget.setItem(
                            rowPosition, idx, item['checkbox'].cell)
                        self.tableWidget.setCellWidget(
                            rowPosition, idx, item['checkbox'])
                        item['checkbox'].checkbox.clicked.connect(
                            lambda state, itemKey=itemKey: self.slotSelect(itemKey))
                    else:
                        cell = QtWidgets.QTableWidgetItem()
                        cell.setData(Qt.DisplayRole, item['data'][label])
                        cell.setFlags(Qt.ItemIsEnabled)
                        self.tableWidget.setItem(rowPosition, idx, cell)
                rowPosition += 1
            header.show()
            self.tableWidget.show()

    def slotSelect(self, itemKey):
        text = self.label_3.text().split("/")
        data = self.pciGeo[str(itemKey)]
        if data['checked']:
            data['checked'] = False
            data['checkbox'].cell.updateValue(Qt.Unchecked)
            data['rubber'].hide()
            self.label_3.setText(f'{int(text[0])-1}/{text[1]}')
        else:
            data['checked'] = True
            data['checkbox'].cell.updateValue(Qt.Checked)
            data['rubber'].show()
            self.label_3.setText(f'{int(text[0])+1}/{text[1]}')

    def checkAll(self, state):
        self.tableWidget.hide()
        text = self.label_3.text().split("/")
        for key, data in self.pciGeo.items():
            data['checked'] = state == Qt.Checked
            data['checkbox'].checkbox.setChecked(state == Qt.Checked)
            data['checkbox'].cell.updateValue(state)
            if state == Qt.Checked:
                data['rubber'].show()
            else:
                data['rubber'].hide()
        if state == Qt.Checked:
            if len(text) > 1:
                self.label_3.setText(f'{text[1]}/{text[1]}')
        else:
            if len(text) > 1:
                self.label_3.setText(f'0/{text[1]}')
        self.tableWidget.show()

    def importer(self):
        tab = self.pciGeo
        keysTab = []
        if len(tab) > 0:
            self.start.emit()

            listLayer = QgsProject.instance().mapLayersByName('Contours des parcelles')
            layer = None
            if len(listLayer) > 0:
                layer = listLayer[0]
            if layer is None:
                layer = QgsVectorLayer(
                    self.type, 'Contours des parcelles', "memory")
                QgsProject.instance().addMapLayer(layer)
                pr = layer.dataProvider()
                layer.startEditing()
                pr.addAttributes(self.listFields)
                layer.updateFields()
                layer.commitChanges()
            layer.startEditing()
            self.tableWidget.hide()
            QtWidgets.QApplication.processEvents()

            for key, data in tab.items():
                if data['checked']:
                    keysTab.append(key)
                    self.ajoutGeoJson(layer, self.listFields, data['data'])
            self.deleteDup(layer)
            layer.commitChanges()
            for key in keysTab:
                self.tableWidget.removeRow(tab[key]['checkbox'].cell.row())
                self.canvas.scene().removeItem(tab[key]['rubber'])
                del tab[key]

            self.tableWidget.show()
            self.miseAJourInfo(tab, 'parcelles')
            QtWidgets.QApplication.processEvents()
            self.done.emit()
            return True
        return False

    def ajoutGeoJson(self, layer, listFields, resJson):
        geom = shape(resJson['geojson'])
        if layer:
            pr = layer.dataProvider()
            fet = QgsFeature()
            fet.setGeometry(QgsGeometry.fromWkt(geom.wkt))
            fet.setFields(layer.fields())
            for field in listFields:
                fet[field.name()] = resJson[field.name()]
            pr.addFeatures([fet])
        return True

    def getType(self, object):
        if isinstance(object, str):
            return (QVariant.String, "string")
        if isinstance(object, bool):
            return (QVariant.Bool, "boolean")
        if isinstance(object, int):
            return (QVariant.Int, "integer")
        if isinstance(object, float):
            return (QVariant.Double, "double")
        return (QVariant.String, "string")

    def deleteDup(self, layer):

        duplicate_id = []
        for i in layer.getFeatures():
            insee = i['insee']
            prefixe = i['prefixe']
            section = i['section']
            numero = i['numero']
            id = f'{insee}{prefixe}{section}{numero}'
            if (id not in duplicate_id):
                duplicate_id.append(id)
            else:
                layer.deleteFeature(i.id())
