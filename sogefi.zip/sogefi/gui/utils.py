from qgis.PyQt import QtWidgets
from qgis.PyQt.QtCore import Qt

class CheckBox(QtWidgets.QWidget):

    def __init__(self, parent=None):
        QtWidgets.QWidget.__init__(self)
        self.checkbox = QtWidgets.QCheckBox()
        self.checkbox.setChecked(False)

        self.pLayout = QtWidgets.QHBoxLayout(self)
        self.pLayout.addWidget(self.checkbox)
        self.pLayout.setAlignment(Qt.AlignCenter)
        self.pLayout.setContentsMargins(0, 0, 0, 0)
        self.setLayout(self.pLayout)
        self.cell = WidgetItem()
        self.cell.updateValue(Qt.Unchecked)

class WidgetItem(QtWidgets.QTableWidgetItem):

    def __lt__(self, other):
        return self.data(Qt.UserRole) < other.data(Qt.UserRole)

    def updateValue(self, value):
        self.setData(Qt.UserRole, value)
