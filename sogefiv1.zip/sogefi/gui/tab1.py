import os
import json
import re
from shapely.geometry import shape
from sogefi.resources import *

from qgis.PyQt import QtWidgets, uic
from qgis.PyQt.QtCore import QVariant, Qt, QUrl, QByteArray
from qgis.PyQt.QtGui import QStandardItemModel, QStandardItem, QBrush, QColor, QIcon, QPixmap
from qgis.PyQt.QtNetwork import QNetworkAccessManager, QNetworkRequest, QNetworkReply

from qgis.core import *
from qgis.gui import *

from .apiStackCog import StackCog
from .apiStackPci import StackPci

plugin_folder = os.path.dirname(os.path.dirname(__file__))
Tab1Widget, _ = uic.loadUiType(os.path.join(
    plugin_folder, 'ui', 'tab1.ui'))

class Tab1(QtWidgets.QWidget, Tab1Widget):

    def __init__(self, iface, parent=None):
        super(Tab1, self).__init__(parent)
        self.setupUi(self)
        self.iface = iface
        self.settings = QgsSettings()
        # Data
        self.data = None
        with open(plugin_folder + '/api.json') as json_file:
            self.data = json.load(json_file)
        self.fetcherTab = []
        self.featureTab = []

        self.backBtn.hide()
        self.backBtn.clicked.connect(self.pagePrecedent)
        self.nextBtn.clicked.connect(self.pageSuivant)
        self.progressBar.hide()
        self.stackedWidget.currentChanged.connect(self.stackedWidgetChanged)

        self.autoCompleteInput.textChanged.connect(self.autoComplete)
        self.model = QStandardItemModel()
        completer = QtWidgets.QCompleter(self.model, self)
        completer.setCompletionMode(
            QtWidgets.QCompleter.UnfilteredPopupCompletion)
        self.autoCompleteInput.setCompleter(completer)
        completer.activated.connect(self.endInput)

        self.cogStack = None
        self.pciStack = None
        self.apiComboBox.clear()
        if self.settings.value("Sogefi/apiList/cog", False) == "True":
            self.apiComboBox.addItem("COG [Code Officiel Géographique]", "cog")
            self.cogStack = StackCog(
                self.iface, self.featureTab, self.data, self.apiStack)
            self.apiStack.addWidget(self.cogStack)
            self.cogStack.start.connect(self.disableBtn)
            self.cogStack.done.connect(self.enableBtn)
        if self.settings.value("Sogefi/apiList/pci", False) == "True":
            self.apiComboBox.addItem("PCI [Plan Cadastral Informatisé]", "pci")
            self.pciStack = StackPci(
                self.iface, self.featureTab, self.data, self.apiStack)
            self.apiStack.addWidget(self.pciStack)
            self.pciStack.start.connect(self.disableBtn)
            self.pciStack.done.connect(self.enableBtn)
        self.apiComboBox.view().setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.apiComboBox.setStyleSheet("combobox-popup: 0;")
        self.apiComboBox.currentIndexChanged.connect(self.updateApiStack)

    def disableBtn(self):
        self.backBtn.setEnabled(False)
        self.nextBtn.setEnabled(False)
        self.progressBar.show()
        self.progressBar.setMinimum(0)
        self.progressBar.setMaximum(0)
        self.progressBar.setValue(0)
        self.apiComboBox.setEnabled(False)

        QtWidgets.QApplication.processEvents()

    def enableBtn(self):
        self.backBtn.setEnabled(True)
        self.nextBtn.setEnabled(True)
        self.progressBar.hide()
        self.apiComboBox.setEnabled(True)
        QtWidgets.QApplication.processEvents()

    def stackedWidgetChanged(self, index):
        if index == 0:
            self.backBtn.hide()
            self.nextBtn.setText("Suivant >")
            self.nextBtn.disconnect()
            self.nextBtn.clicked.connect(self.pageSuivant)
        elif index == 1:
            self.backBtn.show()
            self.nextBtn.setText("Importer")
            self.nextBtn.disconnect()
            self.nextBtn.clicked.connect(self.importer)

    def pagePrecedent(self):
        self.stackedWidget.setCurrentIndex(0)

    def pageSuivant(self):
        self.fetcherTab.clear()
        self.featureTab.clear()
        row = self.tableWidget.rowCount()
        if row > 0:
            self.progressBar.show()
            self.progressBar.setMinimum(0)
            self.progressBar.setMaximum(0)
            self.progressBar.setValue(0)
            self.tableWidget.setEnabled(False)
            self.nextBtn.setEnabled(False)
        for i in range(row):
            endpoint = self.tableWidget.item(i, 0).text()
            id = self.tableWidget.item(i, 1).text()
            listLayer = QgsProject.instance().mapLayersByName(
                f'Contours des {endpoint}')
            layer = None
            if len(listLayer) > 0:
                layer = listLayer[0]
            existe = False
            if layer:
                for feature in layer.getFeatures():
                    if feature.fieldNameIndex('insee') != -1:
                        if feature['insee'] == id:
                            self.featureTab.append(feature)
                            existe = True
                            break
                    elif feature.fieldNameIndex('code_epci') != -1:
                        if feature['code_epci'] == id:
                            self.featureTab.append(feature)
                            existe = True
                            break
            if not existe:
                url = self.data['cog']['endpoint'][endpoint]['byId']['url']
                url = re.sub('\{.*\}', id, url)
                fetcher = QgsNetworkContentFetcher()
                fetcher.fetchContent(QUrl(url))
                fetcher.finished.connect(
                    lambda fetcher=fetcher, endpoint=endpoint: self.etape1(fetcher, endpoint))
                self.fetcherTab.append(fetcher)
        fini = True
        for i in self.fetcherTab:
            if (i.reply() is None) or (not i.reply().isFinished()):
                fini = False
        if fini and row > 0:
            self.tableWidget.setEnabled(True)
            self.nextBtn.setEnabled(True)
            self.progressBar.hide()
            self.stackedWidget.setCurrentIndex(1)

        if self.cogStack is not None:
            self.cogStack.reset()
        if self.pciStack is not None:
            self.pciStack.reset()

    def etape1(self, fetcher, endpoint):
        reply = fetcher.reply()
        if (reply is not None) and reply.error() == QNetworkReply.NoError:
            resJson = json.loads(fetcher.contentAsString())
            listFields = []
            for key in resJson.keys():
                if not(isinstance(resJson[key], dict) or isinstance(resJson[key], list)):
                    typeField, typeName = self.getType(resJson[key])
                    listFields.append(QgsField(key, typeField, typeName))
                elif key == 'geojson':
                    geom = shape(resJson[key])
                    type = resJson[key]['type']
            listLayer = QgsProject.instance().mapLayersByName(
                f'Contours des {endpoint}')
            layer = None
            if len(listLayer) > 0:
                layer = listLayer[0]
            if layer:
                pr = layer.dataProvider()
                layer.startEditing()
                fet = QgsFeature()
                fet.setGeometry(QgsGeometry.fromWkt(geom.wkt))
                fet.setFields(layer.fields())
                for field in listFields:
                    fet[field.name()] = resJson[field.name()]
                pr.addFeatures([fet])
                # Commit changes
                layer.commitChanges()
                self.featureTab.append(fet)
                QgsProject.instance().addMapLayer(layer)
            else:
                layer = QgsVectorLayer(
                    type, f'Contours des {endpoint}', "memory")
                pr = layer.dataProvider()
                layer.startEditing()
                # add fields
                pr.addAttributes(listFields)
                layer.updateFields()
                # add a feature
                # To just create the layer and add features later, delete the four lines from here until Commit changes
                fet = QgsFeature()
                fet.setGeometry(QgsGeometry.fromWkt(geom.wkt))
                fet.setFields(layer.fields())
                for field in listFields:
                    fet[field.name()] = resJson[field.name()]
                pr.addFeatures([fet])
                layer.commitChanges()
                self.featureTab.append(fet)
                QgsProject.instance().addMapLayer(layer)
        fini = True
        for i in self.fetcherTab:
            if (i.reply() is None) or (not i.reply().isFinished()):
                fini = False
        if fini:
            self.tableWidget.setEnabled(True)
            self.nextBtn.setEnabled(True)
            self.progressBar.hide()
            self.stackedWidget.setCurrentIndex(1)

    def updateApiStack(self, index):
        self.apiStack.setCurrentIndex(index)

    def autoComplete(self):
        text = self.autoCompleteInput.text()
        body = json.dumps({"name": text})
        data = QByteArray()
        data.append(body)
        manager = QNetworkAccessManager(self)
        manager.finished[QNetworkReply].connect(self.populateInput)
        req = QNetworkRequest(QUrl("https://api.sogefi.io/cog/autocomplete"))
        req.setHeader(QNetworkRequest.ContentTypeHeader, "application/json")
        manager.post(req, data)

    def populateInput(self, reply):
        res = str(reply.readAll(), 'utf-8')
        if (reply is not None) and reply.error() == QNetworkReply.NoError:
            resJson = json.loads(res)
            self.model.clear()
            keys = [x for x in resJson.keys() if x in self.data['cog']
                    ['endpoint'].keys()]
            for i in keys:
                if len(resJson[i]) != 0:
                    header = QStandardItem(i)
                    header.setBackground(QBrush(QColor(254, 196, 105)))
                    header.setSelectable(False)
                    self.model.appendRow(header)
                    for j in resJson[i]:
                        insee = list(j.keys())[0]
                        s = j['nom'] + f' [{j[insee]}]'
                        item = QStandardItem(s)
                        item.setWhatsThis(i)
                        self.model.appendRow(item)
        reply.deleteLater()

    def endInput(self):
        text = self.autoCompleteInput.text()
        list = self.model.findItems(text)
        if len(list) == 0:
            return
        endpoint = list[0].whatsThis()
        header = self.tableWidget.horizontalHeader()
        header.setSectionResizeMode(0, QtWidgets.QHeaderView.Stretch)
        header.setSectionResizeMode(1, QtWidgets.QHeaderView.Stretch)
        header.setSectionResizeMode(2, QtWidgets.QHeaderView.Stretch)
        header.setSectionResizeMode(3, QtWidgets.QHeaderView.ResizeToContents)
        if text and endpoint:
            rowPosition = self.tableWidget.rowCount()
            self.tableWidget.insertRow(rowPosition)
            id = re.search('\[.*\]', text)
            cell1 = QtWidgets.QTableWidgetItem(str(endpoint))
            cell2 = QtWidgets.QTableWidgetItem(str(id.group(0)[1:-1]))
            cell3 = QtWidgets.QTableWidgetItem(
                str(text.replace(str(id.group(0)), '')).strip())
            cell1.setFlags(Qt.ItemIsEnabled)
            cell2.setFlags(Qt.ItemIsEnabled)
            cell3.setFlags(Qt.ItemIsEnabled)
            self.tableWidget.setItem(rowPosition, 0, cell1)
            self.tableWidget.setItem(rowPosition, 1, cell2)
            self.tableWidget.setItem(rowPosition, 2, cell3)
            icon = QIcon()
            icon.addPixmap(
                QPixmap(":/plugins/sogefi/images/remove.png"), QIcon.Normal, QIcon.Off)
            btnRemove = QtWidgets.QPushButton()
            btnRemove.setIcon(icon)
            btnRemove.setStyleSheet("border: none; background: transparent;")
            self.tableWidget.setCellWidget(rowPosition, 3, btnRemove)
            btnRemove.clicked.connect(
                lambda state, cell1=cell1: self.removeRow(cell1))

    def removeRow(self, cell1):
        self.tableWidget.removeRow(cell1.row())

    def getType(self, object):
        if isinstance(object, str):
            return (QVariant.String, "string")
        if isinstance(object, bool):
            return (QVariant.Bool, "boolean")
        if isinstance(object, int):
            return (QVariant.Int, "integer")
        if isinstance(object, float):
            return (QVariant.Double, "double")
        return (QVariant.String, "string")

    def importer(self):
        if self.apiComboBox.currentData() == "cog":
            self.cogStack.importer()
        if self.apiComboBox.currentData() == "pci":
            self.pciStack.importer()
